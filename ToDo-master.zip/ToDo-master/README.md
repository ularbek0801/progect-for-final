# Feedback ![Screenshot_2020-12-28-22-49-37-971_cn wps xiaomi abroad lite](https://user-images.githubusercontent.com/58214386/103230323-5adbb100-495f-11eb-96c9-7b08e11be248.jpg)


## Teammates; Asanov Kubanych and Koshmatov Aibek
# ToDo 
### This siple app created to planning your day

![image](https://user-images.githubusercontent.com/58214386/102722848-1bdda800-432e-11eb-8f58-95bf0c1c0b23.png)

![image](https://user-images.githubusercontent.com/58214386/102723077-cf936780-432f-11eb-93c6-3a4c6e2601ec.png)

![Imgur](https://imgur.com/okDrEG1.png)

* Content
  * java
  * sql

### The program is designed for desktop computers and has its own database for clients

#### Video on youtube 
[![Watch the video](https://i.imgur.com/vKb2F1B.png)](https://www.youtube.com/watch?v=M1jtgSYxtQY)
