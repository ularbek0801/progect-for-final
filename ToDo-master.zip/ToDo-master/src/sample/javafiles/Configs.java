package sample.javafiles;

public class Configs {
    protected static String dbHost = "localhost";
    protected static String dbUser = "SA";
    protected static String dbPass = "k78964545K";
    protected static String dbName = "dbToDO";
}
